package com.xworkz.hema;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Tester {
public static void main(String[] args) {
	String metoInfo = "spring.xml";
	ApplicationContext spring = new ClassPathXmlApplicationContext("metoInfo");
	labour refOFspring= spring.getBean(labour.class);
	refOFspring.work();
}
}
