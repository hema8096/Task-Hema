package com.xworkz.hema;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Tester {
	
	public static void main(String[] args) {
		try {
			
			String metoInfo = "spring.xml";
			ApplicationContext spring = new ClassPathXmlApplicationContext(metoInfo);
			Rocket refOFspring = spring.getBean(Rocket.class);
			refOFspring.launch();
			
		
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
	}

}
